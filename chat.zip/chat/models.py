from django.db import models

class Chat(models.Model):
    chat_id = models.AutoField(primary_key=True)
    message = models.CharField(max_length=50)
    sender_id = models.IntegerField()
    receiver_id = models.IntegerField()
    sendertype = models.CharField(max_length=25)
    receivertype = models.CharField(max_length=25)
    date = models.DateField()
    time = models.TimeField()

    class Meta:
        managed = False
        db_table = 'chat'



