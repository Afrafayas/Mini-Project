from django.conf.urls import url
from chat import views

urlpatterns=[
    # url('sec/',views.doctor),
    url('rec/',views.user),
    # url('dc/(?P<idd>\w+)',views.doctorchat),
    url('dc/(?P<idd>\w+)',views.userchat),

]