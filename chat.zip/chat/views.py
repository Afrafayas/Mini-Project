from django.shortcuts import render
from user.models import User
from chat.models import Chat
import datetime
# Create your views here.
from login.models import Login


def user(request):
    ob= User.objects.all()
    context={
        'u':ob
    }
    return render(request,'chat/view user.html',context)

from django.db.models import Q
def userchat(request,idd):
    a=int(idd)

    ss = request.session["uid"]
    b = int(ss)

    # mydata = Chat.objects.filter(Q(receiver_id=ss) | Q(receiver_id=a)).values()

    obj = User.objects.get(user_id=idd)
    ob = Chat.objects.all()
    context = {
        'kk': ob,
        'uu': obj,
        'sid':b,
        'rid':a
    }
    if request.method == 'POST':
        obk = Chat()
        obk.message = request.POST.get('mssg')
        obk.receiver_id=idd
        obk.sender_id=ss
        obk.date = datetime.date.today()
        obk.time = datetime.datetime.now()
        obk.receivertype = "ruser"
        obk.sendertype = "suser"
        obk.sender_id = ss
        obk.save()
    return render(request, 'chat/chatuser2.html',context)





#
# def doctor(request):
#     ob= User.objects.all()
#     context={
#         'uu':ob
#     }
#     return render(request, 'chat/view user2.html', context)
#
# def doctorchat(request,idd):
#     obj = User.objects.get(d_id=idd)
#     ob=Chat.objects.all()
#     context={
#         'kk':ob,
#         'uu':obj,
#     }
#     ss = request.session["user_id"]
#     if request.method=='POST':
#         obk=Chat()
#         obk.message=request.POST.get('mssg')
#         obk.p_id=ss
#         obk.d_id=idd
#         obk.date=datetime.date.today()
#         obk.time=datetime.datetime.now()
#         obk.receivertype="ruser"
#         obk.sendertype="suser"
#         obk.sender_id=ss
#         obk.save()
#     return render(request, 'chat/chatuser2.html',context)
